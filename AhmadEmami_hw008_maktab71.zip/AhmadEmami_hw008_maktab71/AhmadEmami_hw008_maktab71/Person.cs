﻿namespace AhmadEmami_hw008_maktab71
{

    public class Person
    {
        
        public int Id { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
    }

     static class PersonRepository
     {
         private static readonly List<Person> _persons;

          static PersonRepository()
         {
             _persons = new List<Person>();
            _persons.Add(new Person()
            {
                Id=10001,
                FName = "Ahmad",
                LName = "Emami"
            });
            _persons.Add(new Person()
            {
                Id = 10002,
                FName = "Ali",
                LName = "Khalili"
            });
            _persons.Add(new Person()
            {
                Id = 10003,
                FName = "Mohammad",
                LName = "Shahsavari"
            });
            _persons.Add(new Person()
            {
                Id = 10004,
                FName = "Hamed",
                LName = "Abedini"
            });
            _persons.Add(new Person()
            {
                Id = 10005,
                FName = "Samaneh",
                LName = "Soltani"
            });
        }

          public static List<Person> GetAllPersons()
          {
              return _persons;
          }


     }


 }




