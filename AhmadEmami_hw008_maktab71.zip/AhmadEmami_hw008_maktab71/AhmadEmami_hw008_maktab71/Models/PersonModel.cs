﻿namespace AhmadEmami_hw008_maktab71.Models
{
    public class PersonModel
    {
        public int Id { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
    }
}
