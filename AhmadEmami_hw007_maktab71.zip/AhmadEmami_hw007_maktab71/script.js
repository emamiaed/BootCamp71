

function changeDefualt() {
    var divElement = document.getElementById("textBox");
    divElement.style.top = "100px";
    divElement.style.left = "60px";

  }


  

