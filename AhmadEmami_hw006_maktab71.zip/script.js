const data = [
  'Teal',
  'SkyBlue',
  'DarkSeaGreen',
  'Purple',
  'LightPink',
  'Crimson'
];
const defaultColor = 'Silver';

function addOption() {
  var selectOption = document.getElementById('color-select');
  for (let index = 0; index < data.length; index++) {
    const optionText = data[index];
    let el = document.createElement("option");
    el.textContent = optionText;
    el.value = optionText;
    selectOption.appendChild(el);
  }
}


function changeBg() {
  let selectElementValue = document.getElementById('color-select').value;
  let divElement = document.querySelector('#box');
  divElement.style.background = selectElementValue;
}

function changeDefualt() {
  let divElement = document.querySelector('#box');
  divElement.style.background = defaultColor;
}

function func() {
  setTimeout(changeDefualt, 1500);
}



let mychange = document.getElementById('color-select');
mychange.addEventListener('click', addOption());
mychange.addEventListener('click', changeBg);
mychange.addEventListener('click', func);

